<?php

namespace Guzzle\Tests\Mock;

class MockSubject extends \Guzzle\Common\Event\AbstractSubject
{
}
