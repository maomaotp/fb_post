Go search on <http://google.com>!

link should be url decoded: <http://en.wikipedia.org/wiki/Mase_%28disambiguation%29>

Brackets in url and backslashes in links:

About port info on wiki: [port](http://en.wikipedia.org/wiki/Port_(computer_networking))

About port info on wiki: [port](http://en.wikipedia.org/wiki/Port_(computer_networking) "port wiki")

[I'm an inline-style link](https://www.google.com)

[I'm an inline-style link with title](https://www.google.com "Google's Homepage")
and another one in the same paragraph:
[I'm an inline-style link with title](https://www.google.com "Google's Homepage")

[I'm a relative reference to a repository file](../blob/(master)/LICENSE)

Or leave it empty and use the [link text itself]()

A [link [in a link](http://example.com)](http://example.com)
