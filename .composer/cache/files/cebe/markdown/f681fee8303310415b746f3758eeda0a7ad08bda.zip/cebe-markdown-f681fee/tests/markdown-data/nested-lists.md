- list1
 - list2
- list3

------

- list1
  - list2
- list3

------

 - list1
  - list2
 - list3

------

 - list1
   - list2
 - list3

------

  - list1
   - list2
  - list3

------

  - list1
    - list2
  - list3

------

   - list1
    - list2
   - list3

------

   - list1
     - list2
   - list3

------

1. li

2. li

   - li
   - li

3. li

------

1. li
2. li
   - li
   - li
3. li

------
