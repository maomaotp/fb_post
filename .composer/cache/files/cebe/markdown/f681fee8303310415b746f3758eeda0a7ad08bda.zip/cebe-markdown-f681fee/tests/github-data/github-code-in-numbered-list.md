1. Item one.
2. Item two with some code:

   ```
   code one
   ```

3. Item three with code:

   ```
   code two
   ```

Paragraph.