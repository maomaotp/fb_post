1. item1, num1
2. item2, num2
4. item3, num3

---

3.   item1, num3
12.  item2, num4
125. item3, num5

---

4. item1, num4
12. item2, num5
125. item3, num6

---

  5. item1, num5
 12. item2, num6
125. item3, num7