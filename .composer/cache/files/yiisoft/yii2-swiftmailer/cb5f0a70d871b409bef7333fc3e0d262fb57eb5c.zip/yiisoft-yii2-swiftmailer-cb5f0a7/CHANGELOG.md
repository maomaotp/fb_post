Yii Framework 2 swiftmailer extension Change Log
================================================

2.0.3 March 01, 2015
--------------------

- no changes in this release.


2.0.2 January 11, 2015
----------------------

- no changes in this release.


2.0.1 December 07, 2014
-----------------------

- no changes in this release.


2.0.0 October 12, 2014
----------------------

- no changes in this release.


2.0.0-rc September 27, 2014
---------------------------

- no changes in this release.


2.0.0-beta April 13, 2014
-------------------------

- Bug #1817: Message charset not applied for alternative bodies (klimov-paul)

2.0.0-alpha, December 1, 2013
-----------------------------

- Initial release.
